import os

class Producto:
    def __init__(self, nombre_comercial, nombre_tecnico, cantidad_disponible, punto_reorden):
        self.nombre_comercial = nombre_comercial
        self.nombre_tecnico = nombre_tecnico
        self.cantidad_disponible = cantidad_disponible
        self.punto_reorden = punto_reorden
        self.siguiente = None  # Siguiente nodo en la lista enlazada

    def mostrar_informacion(self):
        print("\n┌" + "─" * 50 + "┐")
        print(f"│ Nombre Comercial : {self.nombre_comercial:<30} │")
        print(f"│ Nombre Técnico   : {self.nombre_tecnico:<30} │")
        print(f"│ Cantidad         : {self.cantidad_disponible:<30} │")
        print(f"│ Punto de Reorden : {self.punto_reorden:<30} │")
        print("└" + "─" * 50 + "┘")


class InventarioFarmacia:
    def __init__(self):
        self.cabeza = None  # Primer nodo de la lista enlazada

    def ingresar_producto(self):
        print("\n" + "═" * 60)
        print("                     INGRESAR PRODUCTO")
        print("═" * 60)
        nombre_comercial = input("Nombre Comercial: ")
        nombre_tecnico = input("Nombre Técnico: ")
        cantidad_disponible = int(input("Cantidad Disponible: "))
        punto_reorden = int(input("Punto de Reorden: "))

        nuevo_producto = Producto(nombre_comercial, nombre_tecnico, cantidad_disponible, punto_reorden)
        if not self.cabeza:
            self.cabeza = nuevo_producto
        else:
            actual = self.cabeza
            while actual.siguiente:
                actual = actual.siguiente
            actual.siguiente = nuevo_producto
        print(f"\n✔ Producto '{nombre_comercial}' ingresado exitosamente.")

    def sacar_producto(self):
        print("\n" + "═" * 60)
        print("                       SACAR PRODUCTO")
        print("═" * 60)
        nombre_comercial = input("Ingrese el nombre comercial del producto a sacar: ")
        cantidad = int(input("Cantidad a retirar: "))

        actual = self.cabeza
        while actual:
            if actual.nombre_comercial == nombre_comercial:
                if actual.cantidad_disponible >= cantidad:
                    actual.cantidad_disponible -= cantidad
                    print(f"\n✔ Se han retirado {cantidad} unidades de '{nombre_comercial}'.")
                    if actual.cantidad_disponible <= actual.punto_reorden:
                        print("⚠ ¡Atención! La cantidad disponible ha alcanzado el punto de reorden.")
                else:
                    print("\n✘ No hay suficiente cantidad disponible.")
                return
            actual = actual.siguiente
        print("\n✘ Producto no encontrado.")

    def buscar_producto(self):
        print("\n" + "═" * 60)
        print("                     BUSCAR PRODUCTO")
        print("═" * 60)
        nombre_comercial = input("Ingrese el nombre comercial del producto a buscar: ")

        actual = self.cabeza
        while actual:
            if actual.nombre_comercial == nombre_comercial:
                print("\n✔ Producto encontrado:")
                actual.mostrar_informacion()
                return
            actual = actual.siguiente
        print("\n✘ Producto no encontrado.")

    def eliminar_producto(self):
        print("\n" + "═" * 60)
        print("                     ELIMINAR PRODUCTO")
        print("═" * 60)
        nombre_comercial = input("Ingrese el nombre comercial del producto a eliminar: ")

        actual = self.cabeza
        previo = None
        while actual:
            if actual.nombre_comercial == nombre_comercial:
                if previo:
                    previo.siguiente = actual.siguiente
                else:
                    self.cabeza = actual.siguiente
                print(f"\n✔ Producto '{nombre_comercial}' eliminado del inventario.")
                return
            previo = actual
            actual = actual.siguiente
        print("\n✘ Producto no encontrado.")

    def mostrar_inventario(self):
        print("\n" + "═" * 60)
        print("                    INVENTARIO ACTUAL")
        print("═" * 60)
        actual = self.cabeza
        if not actual:
            print("✘ El inventario está vacío.")
            return
        while actual:
            actual.mostrar_informacion()
            actual = actual.siguiente


def menu():
    inventario = InventarioFarmacia()
    while True:
        print("\n" + "═" * 60)
        print("            MENÚ DE INVENTARIO DE FARMACIA")
        print("═" * 60)
        print("1. Ingresar nuevo producto")
        print("2. Sacar producto")
        print("3. Buscar producto")
        print("4. Eliminar producto")
        print("5. Mostrar inventario")
        print("6. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            inventario.ingresar_producto()
        elif opcion == "2":
            inventario.sacar_producto()
        elif opcion == "3":
            inventario.buscar_producto()
        elif opcion == "4":
            inventario.eliminar_producto()
        elif opcion == "5":
            inventario.mostrar_inventario()
        elif opcion == "6":
            print("\nSaliendo del programa...")
            break
        else:
            print("\n✘ Opción no válida. Intente nuevamente.")
        input("\nPresione Enter para continuar...")  # Pausa antes de limpiar
        os.system('cls' if os.name == 'nt' else 'clear')


# Iniciar el menú
menu()
